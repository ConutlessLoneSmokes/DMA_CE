# 实验记录

更新：2026-10-26。这里集中记录实验状态与简要结论；完整条件、数据和科学解释见对应报告。

## 当前状态

2026-10-26研究讨论：用户已确认将导频阶段的DMA配置设计与信道恢复一起纳入候选范围；比较配置设计时固定发送能量、导频符号和频点，固定配置比较CE方法时可改变发射功率扫描接收SNR。优先使用跨场景共用的固定配置序列与导频，硬件频响参数设为已知。已同意先单独检验配置，要求较快冻结，主贡献回到CE算法。一次短选择 `configuration_probe_20261026_v1` 已写明两个候选、32验证几何、三个共同发送功率点、100步SBL及600秒计算上限；入口已准备，尚未启动。具体CE算法仍待讨论。[原文核查、已采纳决定与短选择约定](research/DMA_CROSSFREQUENCY_LITERATURE_20261024.md)。

2026-10-24原文核查：用户希望回到THz宽带DMA信道估计的主线，重点考察配置的跨频幅相响应。只读核查确认真实逐频DMA矩阵已用于各基线，尚未围绕共享调谐变量设计采集；已找到宽带DMA张量CE、频率选择性单次波束训练及联合学习测量设计等近邻。最相近张量CE的固定波导模型与频变失配实验已核原文，但尚未证明新颖性。

结构化先验探查 `structured_prior_20261023_v1` 已完成，五SNR、32验证/32新筛选几何，计算599.26秒。模型内协方差在−10/0 dB分别改善0.01556/0.00377 dB，配对95%区间均大于零；10 dB及以上选择零统计项。未知几何物理恢复明显弱于SBL：30 dB逐频修正−19.143、共同系数联合修正−2.017，SBL为−36.093 dB。固定已估几何，即使完整真值投影也只能达到共同系数−2.025 dB，支持本轮几何表示存在限制，尚未分开LoS、初值和搜索原因。独立评分及原NumPy传播重放通过；完整缓存已归档并核对。[实验分析](../results/structured_prior_20261023_v1/interpretation.md) · [规格与复现](guides/STRUCTURED_PRIOR_PROBE.md)。

答复补充：固定几何的表达限制只约束已经估出的那套角距；完整物理模型在真几何下仍能准确表示本轮信道。共同路径系数的含义、从SBL到三峰的精度损失、厘米级距离误差的宽带相位影响及尚未区分的原因，已补入[结论释义](research/STRUCTURED_PRIOR_OPTIONS_20261023.md)。本次仅解释已完成结果，未运行新实验。

固定观测的先验互补探查 `prior_complementarity_20261023_v1` 已完成：复用512训练/64验证，32个新独立几何、9个SNR。−10 dB时SBL100＋LMMSE改善0.0947 dB，配对95%区间[0.0450, 0.1347]；只融合零空间改善0.0881 dB。逐频LMMSE几乎给出同样收益，不能归因额外跨频协方差；−5 dB及以上LMMSE权重冻结为0。真实几何下的共同物理路径系数比逐频自由系数好约15.91 dB，只说明已知几何时的条件潜力。高SNR约0.1 dB仅是期望，不设性能验收门槛。[实验分析](../results/prior_complementarity_20261023_v1/interpretation.md) · [先验与文献核查](research/PRIOR_COMPLEMENTARITY_20261023.md)。

密集多 RF 阵列的4×256单元、4RF、30 GHz、J=32正式512/64/128几何SNR扫描已完成，仍是单训练抽样、单DMA状态、单网络初始化的探索性实验。100步SBL输入在九个SNR点均优于充分SBL，DDPM则在九点均增加输入的平均误差；30 dB分别为−36.526、−36.492、−31.065 dB。可靠度输入为零，验证集各SNR的末端一致性均选0。[独立复算与机制分析](../results/multirf_snr_analysis_20261023_v1/interpretation.md) · [原始导出](../results/multirf_snr_20261022_v1/report.md) · [研究进程与待讨论方向](research/RESEARCH_PROGRESS_20261023.md)。

表中早期实验使用32阵元、32子载波的单RF缩小系统，最新多RF实验的规模见首行；它们均属探索性实验。NMSE按场景在线性尺度平均后转dB，初始化与条件平均顺序见各报告。

| 日期与运行 | 主要结论 | 证据 |
|---|---|---|
| 2026-10-23，structured_prior_20261023_v1 | 模型内协方差仅低SNR小幅增益；未知几何物理约束退化，固定几何真值投影显示表示误差；保留全部负结果，不据oracle推定实际增益 | [分析](../results/structured_prior_20261023_v1/interpretation.md) |
| 2026-10-23，prior_complementarity_20261023_v1 | 32个新几何；−10 dB统计融合有约0.095 dB小收益，主要在线性误差的零空间分量，尚不能归因跨频协方差；oracle显示严格跨频物理耦合的条件潜力 | [分析](../results/prior_complementarity_20261023_v1/interpretation.md) |
| 2026-10-23，multirf_snr_20261022_v1 | 1024单元多RF正式配置；DDPM低SNR相对充分SBL的小优势已存在于100步输入中，生成自身无平均精修收益；30 dB有8个SBL未达一阶阈值，保留于主结果，排除后的配对差几乎不变 | [分析](../results/multirf_snr_analysis_20261023_v1/interpretation.md) |
| 2026-10-22，观测数扫描3/30 GHz | 512训练、64验证、128筛选几何；J=4–64。30 dB、J=64时SBL为−36.232/−35.914 dB；−10 dB小J仍弱于LMMSE。LS在J=32放大噪声；30 GHz联合样本LMMSE训练子空间投影下限约−3.58 dB | [分析与完整运行ID](../results/observation_baselines_analysis_20261022_v1/interpretation.md) |
| 2026-10-21，physical_baselines_20261021_v2 | 固定热环境的三种路径模型、五方法，512/64/128几何；0 dBm时SBL随机增益−15.539、物理无吸收−14.395 dB，单独吸收影响≤0.0013 dB；物理修正未消除LS与联合LMMSE异常 | [分析](../results/physical_baselines_20261021_v2/interpretation.md) |
| 2026-10-21，linear_baselines_20261021_v2 | 512/64/256几何；30 dB下联合LMMSE +1.778、逐频−2.253、验证冻结收缩−2.039 dB | [报告](../results/linear_baselines_20261021_v2/report.md) |
| 2026-10-20，snr_comparison_20261020_v1 | 9个SNR、128新筛选几何、3初始化；20 dB下密SBL−17.319、原条件DDPM−14.609、DDPM先验＋学习更新−2.015 dB，三轮新组合未达到中高SNR的SBL精度 | [报告](../results/snr_comparison_20261020_v1/interpretation.md) |
| 2026-10-20，research_003 | 修正SBL后重建缓存并训练；5初始化匹配评价：密SBL−11.704、无可靠度确定性精修−11.560、DDPM十六次平均−10.627 dB | [复核](../results/research_003_review_20261020_v1/report.md) |

## 异常、失败与修正

- 先验互补探查首次因服务器持久盘不足2.5 GB在创建运行前退出；改用空闲内存临时盘完成计算，完整缓存复制至本地并按交付清单核对。100步SBL为固定预算，288个输出均未到原一阶停止阈值，全部保留，不称已收敛。
- 结构化先验规格审查发现可微传播在反射点与发射机重合时未按原模型拒绝，已先用失败回归复现并修正，再启动完整实验；受影响数学/物理检查通过。新实验两种SBL均固定100步，160个场景条件输出各自全部未达原一阶阈值，未剔除。低SNR局部几何修正的观测残差下降与CSI退化同时保留。
- 原SBL单步变化阈值提前停止，曾出现密字典弱于粗字典；[诊断](../results/sbl_dictionary_diagnostic_20261019_v1/report.md)保留原失败，改为同一边缘似然目标的凸上界更新和一阶停止条件后完成[固定观测复查](../results/sbl_corrected_probe_20261020_v1/report.md)，再执行research_003。
- [DDPM分步诊断](../results/snr_comparison_20261020_v1_diagnostic_v2/report.md)保留初始化误差、等能量随机方向对照、去噪与观测更新各阶段数据。
- [线性基线诊断](../results/linear_baseline_probe_20261020_v1/report.md)及[协方差样本数对照](../results/baseline_covariance_probe_20261020_v1/report.md)区分观测缺失、噪声和统计估计问题。收缩v1的隐式float32掩码乘法在v2改为双精度；候选、验证规则和筛选观测保持不变，逐场景NMSE最大变化2.3842e−7，见[修正对照](../results/linear_baselines_20261021_v2/precision_comparison.json)。
- 物理模型v1冻结后因缓存NumPy标量不能安全恢复而停止，v2修复缓存类型，科学配置和筛选场景不变；[修正记录](../results/physical_baselines_20261021_v2/implementation_verification.json)保留失败。传播与噪声假设见[物理模型](PHYSICAL_MODEL.md)。
- 观测数扫描8192个SBL输出中1个未达一阶阈值，已保留；统计与排除该点的描述性对照见[分析](../results/observation_baselines_analysis_20261022_v1/interpretation.md)。

## 历史探索

以下使用修正前SBL，保留研究经过，不与修正后的基线合并排名。

- [首轮筛选](../results/pilot_20261016_v1/report.md)：8条件、128几何，可靠度残差扩散弱于当时100次SBL；[验证诊断](../results/validation_probe_20261016_v1/report.md)检查迭代与生成平均预算。
- [第二轮可靠度比较](../results/deterministic_20261016_v1/report.md)：可靠度额外收益约0.029 dB，区间包含0。
- research_001在20,000步预算边界停止：8k→20k验证改善0.11091 dB，超过原0.1 dB稳定阈值；见[当时检查](archive/RESEARCH_001_INSPECTION.md)及[退役元数据](archive/RETIRED_SERVER_RUNS.json)。
- [research_002验证总览](../results/research_002_overview_20261019_v1/report.md)：续训至40k，30k→40k改善0.00628 dB；必要原始评分及来源集中保留在结果目录。

数学、物理检查和复算证据汇总于[实现核验](IMPLEMENTATION_CHECKS.md)。历史缓存清理范围见[清理记录](CLEANUP_20261021.md)；早期完整运行主要保存在服务器 `runs/`，先验互补与结构化先验探查因服务器空间不足分别归档于本地 `runs/prior_complementarity_20261023_v1/`、`runs/structured_prior_20261023_v1/`，每个结果目录保留运行ID、配置与来源。
