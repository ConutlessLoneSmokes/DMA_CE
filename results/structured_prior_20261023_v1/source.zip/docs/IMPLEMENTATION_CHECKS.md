# 实现核验记录

2026-10-22密集多RF新增检查：完整77项测试通过，覆盖RF块连接、各带馈线重置、输出噪声白化、平面球面波距离、导频RE/接收观测计数，以及分解LMMSE与原直接公式的一致性。小规模与4×256单元、32频点、J=32完整尺寸短预算流程均覆盖全部9个SNR及4方法；216条逐场景指标复算最大相对差2.99×10⁻⁷。同ID恢复后metrics/summary/frozen哈希一致。短预算SBL未收敛已保留，图显著标为实现检查；正式性能实验未启动。见[核验数据](../results/multirf_validation_20261022_v1/verification.json)与[设计说明](MULTIRF_SNR.md)。

2026-10-21清理时，smoke、尺寸检查和单步续训的生成数据已移除，原报告正文、配置、环境、源码清单及审计字段集中保存于[核验记录](IMPLEMENTATION_CHECKS.json)。这些记录支持实现正确性，不作为方法性能或论文结果。

| 历史运行 | 保存的核验信息 |
|---|---|
| `continuation_parent_smoke_20261019_v1` | 原配置、环境及报告已归档 |
| `continuation_smoke_20261019_v1` | audit.json: passed；implementation_verification.json: passed；validation_audit.json: passed |
| `corrected_sbl_smoke_20261020_v1` | audit.json: passed；validation_audit.json: passed |
| `deterministic_smoke_20261016_v1` | audit.json: passed；status.json: complete |
| `linear_baselines_smoke_20261020_v1` | audit.json: recorded；status.json: complete |
| `linear_baselines_smoke_20261020_v2` | audit.json: recorded；status.json: complete |
| `linear_baselines_smoke_20261021_v3` | audit.json: recorded；status.json: complete |
| `research_smoke_20261018_v2` | audit.json: passed |
| `smoke_20261016_v1` | status.json: complete |
| `snr_comparison_smoke_20261020_v1` | audit.json: passed |
| `snr_comparison_smoke_20261020_v2` | audit.json: passed；resume_verification.json: recorded |
| `continuation_state_probe_20261019_v1` | 原配置、环境及报告已归档 |
| `research_shape128_20261018_v2` | status.json: passed |

测试源码与`configs/*smoke.json`配置继续保留，后续检查可在新运行ID下重新生成。当前正式结果各自保留独立审计，见[实验记录](EXPERIMENT_LOG.md)。

2026-10-21新增物理模型检查：69项数学与实现检查完整通过，覆盖热噪声、接收机白化、反射及总路径相位、吸收开关与安全缓存恢复。`physical_smoke_20261021_v2`完成600条指标重算，最大差为0；该小流程的50步SBL未收敛，全部保留。配置、审计及v1缓存类型修正记录集中于[本轮实现记录](../results/physical_baselines_20261021_v2/implementation_verification.json)。这些证据支持实现与归档流程，不证明方法性能。

2026-10-22观测数扫描运行前检查：完整73项检查通过。双GPU分别完成3/30 GHz小流程，CPU完成原功率扫描回归；32×32、J=64最大观测形状验证通过。独立重算1160条NMSE/MSE，MSE相对差为0、NMSE最大相对差2.24×10⁻⁷，独立SNR校准差≤4.31×10⁻⁷ dB。相同ID恢复前后的科学数据哈希一致，绘图已目视检查。短预算SBL均未收敛，仅证明流程可执行。见[设计与命令](OBSERVATION_BASELINES.md)及[核验数据](../results/observation_baselines_validation_20261022_v1/verification.json)。

2026-10-22正式观测数结果核验：两带宽40960条指标从保存预测以复双精度独立复算，NMSE最大相对差4.45×10⁻⁷、MSE一致；LS独立重放及联合LMMSE对偶公式检查通过。训练SNR最大校准差4.58×10⁻⁷ dB，几何划分、跨带宽配对、源码/冻结哈希和满行/列秩检查通过。SBL记录为8191/8192达到一阶阈值，未达者保留；未重新运行SBL。见[独立核验](../results/observation_baselines_analysis_20261022_v1/verification.json)及[科学解释](../results/observation_baselines_analysis_20261022_v1/interpretation.md)。
